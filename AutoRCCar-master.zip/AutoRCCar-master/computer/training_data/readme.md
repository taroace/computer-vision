training data is saved in npz format
