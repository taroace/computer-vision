Video frames are saved here
