# VC_OpenCV_Coin_Detection
OpenCV coin detection from VC_2010 

OpenCV 2.4.7.0 Ver.
